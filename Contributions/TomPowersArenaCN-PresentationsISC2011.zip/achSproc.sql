USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_payment_gateway_ACH_Reconciliation]    Script Date: 06/16/2011 00:18:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Tom Powers, SECC
-- Create date: 4/27/2011
-- Description:	Determine estimated (percentage 
--	of grand total) and actual (transaction-based) 
--	payment_gateway ACH fees
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_payment_gateway_ACH_Reconciliation]
	@BEGIN_DATE DATETIME,
	@END_DATE DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Table variable for storing all possible dates
	-- between @BEGIN_DATE and @END_DATE
	DECLARE @calendar TABLE (
	  cal_date VARCHAR(10)
	)

	-- Common table expression for calculating dates
	;WITH cteDates
	AS
	(
	  SELECT CAST(@BEGIN_DATE as datetime) AS cal_date
	  UNION ALL
	  SELECT DATEADD(dd, 1, cal_date)
	  FROM cteDates
	  WHERE DATEADD(dd, 1, cal_date) <= @END_DATE
	)

	-- Populate table variable
	INSERT INTO @calendar (cal_date)
	SELECT CONVERT(VARCHAR(10),cal_date,1) 
	FROM cteDates
	OPTION (MAXRECURSION 0)

	SELECT C.*
	FROM
	(
		-- Event registrations
		SELECT LEFT(CSPG.Comment1,13) AS comment1, CONVERT(VARCHAR(10),CSPG.[Time],1) AS [time], 
			SUM(CASE WHEN CSPG.[Type]='Sale' THEN CSPG.Amount ELSE -1.0*CSPG.Amount END) AS amount,
			1.0 AS multiplier, COUNT(*) AS freq
		FROM cust_SECC_payment_gateway CSPG
		WHERE CSPG.[Tender Type] LIKE 'ACH%' AND 
			CSPG.[Time] >= @BEGIN_DATE AND CSPG.[Time] < DATEADD(d,1,@END_DATE) AND CSPG.Comment1 NOT LIKE 'F%:%' 
		GROUP BY LEFT(CSPG.Comment1,13),CONVERT(VARCHAR(10),CSPG.[Time],1)

		UNION ALL
		
		-- Online giving
		SELECT CF.fund_name AS comment1, CONVERT(VARCHAR(10),CSPG.[Time],1) AS [time], 
			SUM(CCF.amount) AS amount, 1.0/B.num_funds AS multiplier, COUNT(*) AS freq
		FROM cust_SECC_payment_gateway CSPG
		INNER JOIN ctrb_contribution CC ON CSPG.[Gateway Transaction ID] = CC.transaction_number
		INNER JOIN ctrb_contribution_fund CCF ON CC.contribution_id = CCF.contribution_id
		INNER JOIN ctrb_fund CF ON CCF.fund_id = CF.fund_id
		INNER JOIN 
		(
			SELECT A.[Gateway Transaction ID], COUNT(*) AS num_funds
			FROM
			(
				SELECT CSPG.[Gateway Transaction ID]
				FROM cust_SECC_payment_gateway CSPG
				INNER JOIN ctrb_contribution CC ON CSPG.[Gateway Transaction ID] = CC.transaction_number
				INNER JOIN ctrb_contribution_fund CCF ON CC.contribution_id = CCF.contribution_id
				WHERE comment1 LIKE 'F%:%' AND [Tender Type] LIKE 'ACH%' AND [Time]>= @BEGIN_DATE AND [Time]<DATEADD(d,1,@END_DATE)
			) A
			GROUP BY A.[Gateway Transaction ID]
		) B
		ON CSPG.[Gateway Transaction ID] = B.[Gateway Transaction ID]
		WHERE comment1 LIKE 'F%:%' AND [Tender Type] LIKE 'ACH%' AND [time]>= @BEGIN_DATE AND [time]<DATEADD(d,1,@END_DATE)
		GROUP BY CF.fund_name, CONVERT(VARCHAR(10),CSPG.[Time],1), B.num_funds
	) C
	RIGHT OUTER JOIN @calendar CTE ON C.[Time] = CTE.cal_date  --make sure all dates in date range appear in output, even if there weren't any transactions for a given day

END

GO


