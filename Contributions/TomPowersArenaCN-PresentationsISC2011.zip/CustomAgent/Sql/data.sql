/*data script*/
/*IMPORTANT NOTE:  
	Update values in blocks below as necessary. 
*/

USE ArenaDB

DECLARE @api_username VARCHAR(100)
DECLARE @api_password VARCHAR(100)
DECLARE @api_signature VARCHAR(100)
DECLARE @organization_id INT
/******************************************************************************** **/
/*  UPDATE VALUES BETWEEN '' IN THIS BLOCK										  **/
/*	All values would have been recieved when requesting API signature			  **/
	SET @api_username = 'Your PayPal API username' 
	SET @api_password = 'Your PayPal API password'
	SET @api_signature = 'Your PayPal API signature'

/***********************************************************************************/
/*  UPDATE organization_id if your Organization ID is not 1						   */
	SET @organization_id = 1
/***********************************************************************************/

DECLARE @api_name VARCHAR(100)
DECLARE @api_credential_id INT
DECLARE @arena_user VARCHAR(50)
DECLARE @arena_url VARCHAR(250)

SET @api_name = 'PayPal'
SET @arena_user = 'system'
set @api_credential_id = 0


IF EXISTS(SELECT * FROM cust_secc_api_credentials WHERE api_name = @api_name AND organization_id = @organization_id)
BEGIN
	PRINT 'PayPal credential already exists for organization ' + CAST(@organization_id AS VARCHAR)
END
ELSE
BEGIN
	exec dbo.cust_secc_sp_save_api_credentials @api_credential_id, @api_name, @api_username, @api_password, @api_signature, @organization_id, @arena_url, @api_username, @api_credential_id
	
	PRINT 'PayPal credential ' + CAST(@api_credential_id AS VARCHAR) + ' has been created successfully.'
END


declare @lookup_type_id INT

SELECT @lookup_type_id =  lookup_type_id from core_lookup_type where guid = '4B20142E-0107-430D-9C4F-0942D1C81E21' AND organization_id = @organization_id


if not exists(select * from core_lookup where guid = '67137EB2-E970-4248-AC42-468FA9BDBE57')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '67137EB2-E970-4248-AC42-468FA9BDBE57',@lookup_type_id, '100','Response','Request Completed Successfully','Ok','','','','','',3,1,0 ) end
if not exists(select * from core_lookup where guid = '0C4E35F5-E19F-4A35-A3EB-ED94E62252CD')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '0C4E35F5-E19F-4A35-A3EB-ED94E62252CD',@lookup_type_id, '101','Response','Request Failed','Critical','','','','','',5,1,0 ) end
if not exists(select * from core_lookup where guid = '6673C7F6-689B-41C4-A9FA-94534D47AF79')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '6673C7F6-689B-41C4-A9FA-94534D47AF79',@lookup_type_id, '102','Response','An internal scheduler error has occurred','Critical','','','','','',7,1,0 ) end
if not exists(select * from core_lookup where guid = '042DBBD2-5FC2-46DE-B3C4-65647F41C10B')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '042DBBD2-5FC2-46DE-B3C4-65647F41C10B',@lookup_type_id, '103','Response','Unknown Report Name','Critical','','','','','',9,1,0 ) end
if not exists(select * from core_lookup where guid = '4D2900B1-C5A5-4EE8-AA21-6C895F4FC6BF')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '4D2900B1-C5A5-4EE8-AA21-6C895F4FC6BF',@lookup_type_id, '104','Response','Invalid Report ID','Warning','','','','','',11,1,0 ) end
if not exists(select * from core_lookup where guid = 'FD48BFFA-4A9E-4AB1-BAF4-0DCE76009BA9')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'FD48BFFA-4A9E-4AB1-BAF4-0DCE76009BA9',@lookup_type_id, '105','Response','System Error','Critical','','','','','',13,1,0 ) end
if not exists(select * from core_lookup where guid = 'C71593A0-2647-442D-BDE5-459628481A83')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'C71593A0-2647-442D-BDE5-459628481A83',@lookup_type_id, '106','Response','Database Error','Critical','','','','','',15,1,0 ) end
if not exists(select * from core_lookup where guid = '72F0A810-093D-4C23-B9FB-E12C93E0B583')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '72F0A810-093D-4C23-B9FB-E12C93E0B583',@lookup_type_id, '107','Response','Invalid XML Request','Exception','','','','','',17,1,0 ) end
if not exists(select * from core_lookup where guid = '789E3348-B047-487A-90CD-808B29EE28C9')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '789E3348-B047-487A-90CD-808B29EE28C9',@lookup_type_id, '108','Response','User Authentication Failed','Exception','','','','','',19,1,0 ) end
if not exists(select * from core_lookup where guid = 'ED07B723-ACA4-4D8F-80E3-14F55DE3F40B')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'ED07B723-ACA4-4D8F-80E3-14F55DE3F40B',@lookup_type_id, '109','Response','Invaild Report Parameters Provided','Exception','','','','','',21,1,0 ) end
if not exists(select * from core_lookup where guid = 'B3DD2091-401C-47C8-9FF3-E971C9A198BA')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'B3DD2091-401C-47C8-9FF3-E971C9A198BA',@lookup_type_id, '110','Response','Invalid Merchant Account','Exception','','','','','',23,1,0 ) end
if not exists(select * from core_lookup where guid = '55318E59-3106-4945-B071-6DB84ACC0B8F')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '55318E59-3106-4945-B071-6DB84ACC0B8F',@lookup_type_id, '111','Response','Invalid Page Number','Warning','','','','','',25,1,0 ) end
if not exists(select * from core_lookup where guid = '34B1A796-F454-4FF3-87EF-BC752613C134')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '34B1A796-F454-4FF3-87EF-BC752613C134',@lookup_type_id, '112','Response','Template Aready Exists','Critical','','','','','',27,1,0 ) end
if not exists(select * from core_lookup where guid = 'ABA556A3-3EA4-433D-8B4F-9621A9C5DF8E')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'ABA556A3-3EA4-433D-8B4F-9621A9C5DF8E',@lookup_type_id, '113','Response','Unknown Template Requested','Critical','','','','','',29,1,0 ) end
if not exists(select * from core_lookup where guid = '14E394B2-7837-474D-B798-0660264AB5A2')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '14E394B2-7837-474D-B798-0660264AB5A2',@lookup_type_id, '1','Report','Report has been created','Ok','','','','','',1,1,0 ) end
if not exists(select * from core_lookup where guid = '19092BF6-9A7B-41D9-A6CA-825CB8DBC4EE')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '19092BF6-9A7B-41D9-A6CA-825CB8DBC4EE',@lookup_type_id, '2','Report','Report is currently executing','Ok','','','','','',31,1,0 ) end
if not exists(select * from core_lookup where guid = '1B60BD6F-7B66-4865-8832-4FA7F1326D66')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '1B60BD6F-7B66-4865-8832-4FA7F1326D66',@lookup_type_id, '3','Report','Report has complted successfully','Ok','','','','','',33,1,0 ) end
if not exists(select * from core_lookup where guid = '29D7E1BB-C788-4D47-8296-058DD120E96A')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '29D7E1BB-C788-4D47-8296-058DD120E96A',@lookup_type_id, '4','Report','Report has failed','Critical','','','','','',35,1,0 ) end
if not exists(select * from core_lookup where guid = 'AB82B957-4836-4E5B-9F6E-9D748E7F9DBA')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    'AB82B957-4836-4E5B-9F6E-9D748E7F9DBA',@lookup_type_id, '5','Report','Report has expired','Critical','','','','','',37,1,0 ) end
if not exists(select * from core_lookup where guid = '97E6E5AE-9246-4FEE-A2BC-DA220B09DD6B')     begin     insert into core_lookup(guid, lookup_type_id, lookup_value, lookup_qualifier, lookup_qualifier2, lookup_qualifier3, lookup_qualifier4, lookup_qualifier5, lookup_qualifier6, lookup_qualifier7, lookup_qualifier8, lookup_order, active, system_flag)    values(    '97E6E5AE-9246-4FEE-A2BC-DA220B09DD6B',@lookup_type_id, '6','Report','Report has Expired','Critical','','','','','',39,1,0 ) end
