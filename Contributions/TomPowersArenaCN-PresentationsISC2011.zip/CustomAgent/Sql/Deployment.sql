/*SECC.Agent.Contibutions.Reporting deployment script*/

/*
	Tables
		dbo.cust_secc_api_credentials
		dbo.cust_SECC_payment_gateway
	Stored Procedures
		dbo.cust_secc_sp_get_api_credentials_byID
		dbo.cust_secc_get_api_credentials_byName
		dbo.cust_secc_sp_get_paypaltransaction_byTransactionID
		dbo.cust_secc_sp_get_paypalTransactionWithoutPayPalFee
		dbo.cust_secc_sp_save_api_credentials
		dbo.cust_secc_sp_save_PayPalTransaction	
*/

	USE [ArenaDB]
	GO

	/****** Object:  Table [dbo].[cust_secc_api_credentials]    Script Date: 06/02/2011 11:20:04 ******/
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_api_credentials]') AND type in (N'U'))
	DROP TABLE [dbo].[cust_secc_api_credentials]
	GO

	USE [ArenaDB]
	GO

	/****** Object:  Table [dbo].[cust_secc_api_credentials]    Script Date: 06/02/2011 11:20:04 ******/
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO

	SET ANSI_PADDING ON
	GO

	CREATE TABLE [dbo].[cust_secc_api_credentials](
		[api_credential_id] [int] IDENTITY(1,1) NOT NULL,
		[api_name] [varchar](100) NOT NULL,
		[api_username] [varchar](100) NOT NULL,
		[api_password] [varbinary](1000) NOT NULL,
		[api_signature] [varbinary](1000) NULL,
		[organization_id] [int] NULL,
		[date_created] [datetime] NOT NULL,
		[date_modified] [datetime] NULL,
		[created_by] [varchar](50) NOT NULL,
		[modified_by] [varchar](50) NULL,
		[api_url] [varchar](250) NOT NULL,
	 CONSTRAINT [PK_cust_secc_api_credentials] PRIMARY KEY CLUSTERED 
	(
		[api_credential_id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	GO

	SET ANSI_PADDING OFF
	GO

	USE [ArenaDB]
	GO

	/****** Object:  Table [dbo].[cust_SECC_payment_gateway]    Script Date: 06/06/2011 13:39:39 ******/
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_payment_gateway]') AND type in (N'U'))
	DROP TABLE [dbo].[cust_SECC_payment_gateway]
	GO

	USE [ArenaDB]
	GO

	/****** Object:  Table [dbo].[cust_SECC_payment_gateway]    Script Date: 06/06/2011 13:39:39 ******/
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO

	CREATE TABLE [dbo].[cust_SECC_payment_gateway](
		[Gateway Transaction ID] [nvarchar](255) NOT NULL,
		[Tender Type] [nvarchar](255) NULL,
		[Amount] [float] NULL,
		[Comment1] [nvarchar](255) NULL,
		[Time] [datetime] NULL,
		[Type] [nvarchar](255) NULL,
		[Comment2] [nvarchar](255) NULL,
		[Fees] [float] NULL,
		[Merchant Transaction ID] [nvarchar](255) NULL,
	 CONSTRAINT [PK_cust_SECC_payment_gateway] PRIMARY KEY CLUSTERED 
	(
		[Gateway Transaction ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	GO




	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_api_credentials_byID]    Script Date: 06/02/2011 11:27:47 ******/
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_get_api_credentials_byID]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[cust_secc_sp_get_api_credentials_byID]
	GO

	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_api_credentials_byID]    Script Date: 06/02/2011 11:27:47 ******/
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO


	-- =============================================
	-- Author:		Chris Funk
	-- Create date: 05/09/2011
	-- Description:	<Description,,>
	-- =============================================
	CREATE PROCEDURE [dbo].[cust_secc_sp_get_api_credentials_byID]
		@api_credential_id INT
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		
		OPEN SYMMETRIC KEY PasswordKey DECRYPTION BY CERTIFICATE PasswordsCertificate;
		
		SELECT api_credential_id,
			   api_name,
			   api_username,
			   CONVERT(VARCHAR(100), DecryptByKey(api_password, 1, CONVERT(VARBINARY, organization_id))) as api_password,
			   CONVERT(VARCHAR(100), DecryptByKey(api_signature, 1, CONVERT(VARBINARY, organization_id))) as api_signature,
			   organization_Id,
			   date_created,
			   date_modified,
			   created_by,
			   modified_by,
			   api_url
		FROM cust_secc_api_credentials
		WHERE api_credential_id = @api_credential_id
		
		CLOSE SYMMETRIC KEY PasswordKey
	END


	GO

	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_api_credentials_byName]    Script Date: 06/02/2011 11:28:07 ******/
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_get_api_credentials_byName]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[cust_secc_sp_get_api_credentials_byName]
	GO

	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_api_credentials_byName]    Script Date: 06/02/2011 11:28:07 ******/
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO


	-- =============================================
	-- Author:		Chris Funk
	-- Create date: 05/09/2011
	-- Description:	<Description,,>
	-- =============================================
	CREATE PROCEDURE [dbo].[cust_secc_sp_get_api_credentials_byName]
		@api_name VARCHAR(100)
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		
		OPEN SYMMETRIC KEY PasswordKey DECRYPTION BY CERTIFICATE PasswordsCertificate;
		
		SELECT api_credential_id,
			   api_name,
			   api_username,
			   CONVERT(varchar(100), DecryptByKey(api_password, 1, convert(varbinary, organization_id))) as api_password,
			   CONVERT(VARCHAR(100), DecryptByKey(api_signature, 1, convert(varbinary, organization_id))) as api_signature,
			   organization_Id,
			   date_created,
			   date_modified,
			   created_by,
			   modified_by,
			   api_url
		FROM cust_secc_api_credentials
		WHERE api_name = @api_name
		
		CLOSE SYMMETRIC KEY PasswordKey
	END


	GO

	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_save_api_credentials]    Script Date: 06/02/2011 11:28:24 ******/
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_save_api_credentials]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[cust_secc_sp_save_api_credentials]
	GO

	USE [ArenaDB]
	GO

	/****** Object:  StoredProcedure [dbo].[cust_secc_sp_save_api_credentials]    Script Date: 06/02/2011 11:28:24 ******/
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO


	-- =============================================
	-- Author:		<Author,,Name>
	-- Create date: <Create Date,,>
	-- Description:	<Description,,>
	-- =============================================
	CREATE PROCEDURE [dbo].[cust_secc_sp_save_api_credentials]
		@api_credential_id INT,
		@api_name VARCHAR(100),
		@api_username VARCHAR(100),
		@api_password VARCHAR(100),
		@api_signature VARCHAR(100),
		@organization_id INT,
		@user_id VARCHAR(50),
		@api_url VARCHAR(250),
		@ID INT OUTPUT
	AS
	BEGIN

		OPEN SYMMETRIC KEY PasswordKey DECRYPTION BY CERTIFICATE PasswordsCertificate;
		
		DECLARE @UpdatedOn DATETIME set @UpdatedOn = GETDATE()
		

		IF NOT EXISTS(SELECT * FROM cust_secc_api_credentials WHERE api_credential_id = @api_credential_id)
		BEGIN
			INSERT INTO cust_secc_api_credentials(
				api_name,
				api_username,
				api_password,
				api_signature,
				organization_Id,
				date_created,
				date_modified,
				created_by,
				modified_by,
				api_url)
			VALUES(
				@api_name,
				@api_username,
				ENCRYPTBYKEY(Key_GUID('PasswordKey'), @api_password,1, CONVERT(varbinary, @organization_id)),
				ENCRYPTBYKEY(Key_GUID('PasswordKey'), @api_signature,1, CONVERT(varbinary, @organization_id)),
				@organization_id,
				@UpdatedOn, 
				@UpdatedOn, 
				@user_id,
				@user_id,
				@api_url)
				
			SET @ID = SCOPE_IDENTITY()			
		END
		ELSE
		BEGIN
			UPDATE cust_secc_api_credentials
			SET api_name = @api_name,
				api_username = @api_username,
				api_password = ENCRYPTBYKEY(Key_GUID('PasswordKey'), @api_password,1, CONVERT(varbinary, @organization_id)),
				api_signature = ENCRYPTBYKEY(Key_GUID('PasswordKey'), @api_signature,1, CONVERT(varbinary, @organization_id)),
				organization_Id = @organization_id,
				date_modified = @UpdatedOn,
				modified_by = @user_id,
				api_url = @api_url
			WHERE api_credential_id = @api_credential_id
			
			SET @ID = @api_credential_id
			
		END
		
		CLOSE SYMMETRIC KEY PasswordKey
		
	END


	GO


USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_paypaltransaction_byGatewayTransactionID]    Script Date: 06/06/2011 13:37:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_get_paypaltransaction_byGatewayTransactionID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_secc_sp_get_paypaltransaction_byGatewayTransactionID]
GO

USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_paypaltransaction_byGatewayTransactionID]    Script Date: 06/06/2011 13:37:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_secc_sp_get_paypaltransaction_byGatewayTransactionID]
	@GatewayTransactionID NVARCHAR(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT [Gateway Transaction ID],
			[Amount],
			[Comment1],
			[Comment2],
			Fees,
			[Merchant Transaction ID], 
			[Tender Type],
			[Time],
			[Type]
	FROM dbo.cust_SECC_payment_gateway
	WHERE [Gateway Transaction ID] = @GatewayTransactionID
	
	
END


GO



USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_paypalTransactionWithoutFees]    Script Date: 06/06/2011 13:38:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_get_paypalTransactionWithoutFees]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_secc_sp_get_paypalTransactionWithoutFees]
GO

USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_get_paypalTransactionWithoutFees]    Script Date: 06/06/2011 13:38:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_secc_sp_get_paypalTransactionWithoutFees]
AS
BEGIN
	SELECT 
		Amount,
		Comment1,
		Comment2,
		Fees,
		[Merchant Transaction ID],
		[Tender Type],
		[Time],
		[Gateway Transaction ID],
		[Type]
	FROM cust_secc_payment_gateway
	WHERE [Merchant Transaction ID] <> '' and Fees = 0 
END


GO


USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_save_PayPalTransaction]    Script Date: 06/06/2011 13:38:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_secc_sp_save_PayPalTransaction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_secc_sp_save_PayPalTransaction]
GO

USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_secc_sp_save_PayPalTransaction]    Script Date: 06/06/2011 13:38:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Chris Funk
-- Create date: 05/04/2011
-- Description:	Saves PayPal Transaction
-- =============================================
CREATE PROCEDURE [dbo].[cust_secc_sp_save_PayPalTransaction]
	@Amount FLOAT,								--Amount
	@Comment1 NVARCHAR(255),					--Comment1
	@Comment2 NVARCHAR(255),					--Comment2
	@Fees FLOAT,								--PayPal Fees
	@MerchantTransactionID NVARCHAR(255),		--PayPal Transaction ID
	@TenderType NVARCHAR(255),					--Tender Type
	@Time DATETIME,								--Time
	@GatewayTransactionID NVARCHAR(255),		--Transaction ID
	@Type NVARCHAR(255)							--Type
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF NOT EXISTS(SELECT * FROM dbo.cust_SECC_payment_gateway where [Gateway Transaction ID] = @GatewayTransactionID)
	BEGIN
		INSERT INTO	dbo.cust_SECC_payment_gateway
		(
			Amount,
			Comment1,
			Comment2,
			Fees,
			[Merchant Transaction ID],
			[Tender Type],
			[Time], 
			[Gateway Transaction ID],
			[Type]
		)
		VALUES
		(
			@Amount,
			@Comment1,
			@Comment2,
			@Fees,
			@MerchantTransactionID,
			@TenderType,
			@Time,
			@GatewayTransactionID,
			@Type
		)	
	END
	ELSE
	BEGIN
		UPDATE dbo.cust_SECC_payment_gateway SET
			Amount = @Amount,
			Comment1 = @Comment1,
			Comment2 = @Comment2,
			Fees = @Fees,
			[Merchant Transaction ID] = @MerchantTransactionID,
			[Tender Type] = @TenderType,
			[Time] = @Time,
			[Type] = @Type
		WHERE [Gateway Transaction ID] = @GatewayTransactionID
	END
END


GO


