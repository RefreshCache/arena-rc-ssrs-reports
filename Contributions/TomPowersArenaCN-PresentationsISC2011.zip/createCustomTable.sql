USE [ArenaDB]

CREATE TABLE [dbo].[cust_SECC_payment_gateway]
(
[Gateway Transaction ID] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Tender Type] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Amount] [float] NULL,
[Comment1] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Time] [datetime] NULL,
[Type] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Comment2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Fees] [float] NULL,
[Merchant Transaction ID] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
GO
-- Constraints and Indexes

ALTER TABLE [dbo].[cust_SECC_payment_gateway] ADD CONSTRAINT [PK_cust_SECC_payment_gateway] PRIMARY KEY CLUSTERED  ([Gateway Transaction ID])
GO
CREATE NONCLUSTERED INDEX [_dta_index_cust_SECC_payment_gateway_5_1020543415__K5] ON [dbo].[cust_SECC_payment_gateway] ([Time])
GO
CREATE STATISTICS [_dta_stat_1020543415_1_5] ON [dbo].[cust_SECC_payment_gateway] ([Gateway Transaction ID], [Time])
GO
CREATE STATISTICS [_dta_stat_1020543415_2_5] ON [dbo].[cust_SECC_payment_gateway] ([Tender Type], [Time])
GO
CREATE STATISTICS [_dta_stat_1020543415_5_4] ON [dbo].[cust_SECC_payment_gateway] ([Time], [Comment1])
GO