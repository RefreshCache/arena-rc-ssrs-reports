USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_payment_gateway_unbalanced_transactions]    Script Date: 06/16/2011 00:16:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Tom Powers, SECC
-- Create date: 4/27/2011
-- Description:	The contribution total doesn't equal the sum of the individual fund totals 
--		(probably caused by changes to a person's repeating payment profile)
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_payment_gateway_unbalanced_transactions]
	@BEGIN_DATE DATETIME,
	@END_DATE DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- non-matching contributions
	SELECT CC.contribution_date AS [Contribution Date], CCF.contribution_fund_id AS [Contribution Fund ID], 
	CC.person_id AS [Person ID],CCF.fund_id AS [Fund ID],CCF.amount AS [Arena Fund Amount],CC.currency_amount AS [Gateway Transaction Amount], 	
	CSPG.Comment1, CC.transaction_number AS [Gateway Transaction ID]
	FROM ctrb_contribution_fund CCF WITH(NOLOCK)
	INNER JOIN ctrb_contribution CC WITH(NOLOCK) ON CCF.contribution_id = CC.contribution_id
	INNER JOIN cust_SECC_payment_gateway CSPG ON CC.transaction_number = CSPG.[Gateway Transaction ID]
	WHERE CCF.contribution_id IN
	(
		SELECT MIN(CC.contribution_id) AS contribution_id 
		FROM ctrb_contribution CC WITH(NOLOCK)
		INNER JOIN ctrb_contribution_fund CCF WITH(NOLOCK) ON CC.contribution_id = CCF.contribution_id
		WHERE CC.contribution_date >= @BEGIN_DATE AND CC.contribution_date < DATEADD(d,1,@END_DATE)
		GROUP BY CC.contribution_id, CC.currency_amount
		HAVING MAX(CC.currency_amount) <> SUM(CCF.amount) 
	)
END

/* How to fix unbalanced amounts 
DECLARE @amt MONEY
DECLARE @ctrb_fund_id INT
SET @amt = 0 --put the correct amount here
SET @ctrb_fund_id = 0  --put the contribution fund id here

UPDATE ctrb_contribution_fund
SET amount = @amt, date_modified = GETDATE(), modified_by = 'Accounting'
WHERE contribution_fund_id = @ctrb_fund_id
*/
GO


