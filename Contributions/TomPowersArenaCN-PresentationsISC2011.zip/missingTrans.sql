USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_payment_gateway_missing_transactions]    Script Date: 06/16/2011 02:41:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Tom Powers, SECC
-- Create date: 4/27/2011
-- Description:	Event Registration and Online Giving transactions not in Arena
--		(either due to refunds done outside Arena, missing import batches, or data missing from custom payment gateway table)
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_payment_gateway_missing_transactions]
	@BEGIN_DATE DATETIME,
	@END_DATE DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- missing transactions
	SELECT COALESCE(A.[Applies To], B.[Applies To]) AS [Applies To], 
		COALESCE(A.[Gateway Transaction ID],B.[Gateway Transaction ID]) AS [Gateway Transaction ID],
		COALESCE(A.[Merchant Transaction ID],'') AS [Merchant Transaction ID], 
		COALESCE(A.[Time],B.[Time]) AS [Time],
		COALESCE(A.[Amount],B.[Amount]) AS [Amount],
		COALESCE(A.[Tender Type],B.[Tender Type]) AS [Tender Type],
		CASE WHEN COALESCE(A.[Amount],B.[Amount])>=0 THEN 'Sale' ELSE 'Credit' END AS [Type],
		COALESCE(A.[Comment1],B.[Comment1]) AS [Comment1]
	FROM 
	(
		SELECT CASE WHEN CSPG.Comment1 NOT LIKE 'F%:%' THEN 'ER' ELSE 'OG' END AS [Applies To],
			CSPG.[Gateway Transaction ID], 
			CSPG.[Merchant Transaction ID],
			CSPG.[Time],
			CSPG.[Amount],
			CSPG.[Tender Type],
			CSPG.[Comment1]
		FROM cust_SECC_payment_gateway CSPG
		WHERE CSPG.Time >= @BEGIN_DATE AND CSPG.Time < DATEADD(d,1,@END_DATE)
	) A
	FULL OUTER JOIN
	(
		SELECT CASE WHEN COALESCE(PT.notes,CC.memo) NOT LIKE 'F%:%' AND CC.batch_id IS NULL THEN 'ER-not in CGT' ELSE 'OG-not in CGT' END AS [Applies To],
			COALESCE(PT.transaction_detail,CC.transaction_number) AS [Gateway Transaction ID],
			COALESCE(PT.transaction_date,CC.contribution_date) AS [Time],
			COALESCE(PT.transaction_amount,CC.currency_amount) AS [Amount],
			(SELECT lookup_value FROM core_lookup where lookup_id = COALESCE(PT.payment_method_luid,CC.currency_type_luid)) AS [Tender Type],
			CASE WHEN COALESCE(PT.transaction_amount,CC.currency_amount)>=0 THEN 'Sale' ELSE 'Credit' END AS [Type],
			COALESCE(PT.notes,CC.memo) AS [Comment1]
		FROM
		(
			SELECT *
			FROM pmnt_transaction WITH(NOLOCK)
			WHERE transaction_date >= @BEGIN_DATE AND transaction_date < DATEADD(d,1,@END_DATE) AND 
				(notes LIKE 'F%:%' OR payment_method_luid IN (SELECT lookup_id FROM core_lookup WHERE lookup_value IN ('MasterCard','Visa','American Express','Discover','E-Check')))
		) PT
		FULL OUTER JOIN
		(
			SELECT *
			FROM ctrb_contribution WITH(NOLOCK)
			WHERE contribution_date >= @BEGIN_DATE AND contribution_date < DATEADD(d,1,@END_DATE) AND 
				(memo LIKE 'F%:%' OR currency_type_luid IN (SELECT lookup_id FROM core_lookup WHERE lookup_value IN ('MasterCard','Visa','American Express','Discover','E-Check')))
		) CC ON PT.transaction_detail = CC.transaction_number	
	) B ON A.[Gateway Transaction ID] = B.[Gateway Transaction ID]
	WHERE A.[Gateway Transaction ID] IS NULL OR B.[Gateway Transaction ID] IS NULL
	ORDER BY COALESCE(A.[Time],B.[Time]),COALESCE(A.[Gateway Transaction ID],B.[Gateway Transaction ID])

END



GO


