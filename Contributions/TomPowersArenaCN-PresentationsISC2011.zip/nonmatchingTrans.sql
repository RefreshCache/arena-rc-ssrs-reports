USE [ArenaDB]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_payment_gateway_nonmatching_transactions]    Script Date: 06/16/2011 00:17:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Tom Powers, SECC
-- Create date: 4/27/2011
-- Description:	The The Tender Type (MC, Visa, Discover, etc...) in Arena doesn't match the Tender Type at the payment gateway 
--			or the Amount in Arena doesn't match the Amount at the payment gateway (probably due to a manual posting error) 
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_payment_gateway_nonmatching_transactions]
	@BEGIN_DATE DATETIME,
	@END_DATE DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Tender type in Arena doesn't match tender type at payment gateway
	SELECT A.*
	FROM
	(
		SELECT CSPG.[Gateway Transaction ID],CASE WHEN CSPG.Comment1 NOT LIKE 'F%:%' THEN 'ER' ELSE 'OG' END AS [Applies To],
			CASE CSPG.Type WHEN 'Credit' THEN -1.0*CSPG.[Amount] ELSE CSPG.[Amount] END AS [Gateway Amount],
			PT.transaction_amount AS [Arena Amount],CSPG.[Tender Type] AS [Gateway Tender Type],			
			(SELECT lookup_value FROM core_lookup WHERE lookup_id = PT.payment_method_luid) AS [Arena Tender Type],
			CASE WHEN CSPG.[Tender Type] LIKE 'ACH%' THEN (SELECT TOP 1 lookup_id FROM core_lookup WHERE lookup_value='E-Check') ELSE (SELECT TOP 1 lookup_id FROM core_lookup WHERE lookup_value = CSPG.[Tender Type]) END AS [Gateway Tender Type ID],
			PT.payment_method_luid AS [Arena Tender Type ID]
		FROM cust_SECC_payment_gateway CSPG WITH(NOLOCK)
		LEFT OUTER JOIN pmnt_transaction PT WITH(NOLOCK) ON CSPG.[Gateway Transaction ID] = PT.transaction_detail
		WHERE CSPG.[Time] >= @BEGIN_DATE AND CSPG.[Time] < DATEADD(d,1,@END_DATE)
		UNION
		SELECT CC.transaction_number,'OG',CASE CSPG.Type WHEN 'Credit' THEN -1.0*CSPG.[Amount] ELSE CSPG.[Amount] END AS [Gateway Amount],
			CC.currency_amount AS [Arena Amount],CSPG.[Tender Type] AS [Gateway Tender Type],
			(SELECT lookup_value FROM core_lookup WHERE lookup_id = CC.currency_type_luid) AS [Arena Tender Type],
			CASE WHEN CSPG.[Tender Type] LIKE 'ACH%' THEN (SELECT TOP 1 lookup_id FROM core_lookup WHERE lookup_value='E-Check') ELSE (SELECT TOP 1 lookup_id FROM core_lookup WHERE lookup_value = CSPG.[Tender Type]) END AS [Gateway Tender Type ID],
			CC.currency_type_luid AS [Arena Tender Type ID]
		FROM cust_SECC_payment_gateway CSPG WITH(NOLOCK)
		LEFT OUTER JOIN ctrb_contribution CC WITH(NOLOCK) ON CSPG.[Gateway Transaction ID] = CC.transaction_number
		WHERE CC.contribution_date >= @BEGIN_DATE AND CC.contribution_date < DATEADD(d,1,@END_DATE) AND CC.memo LIKE 'F%:%'
	) A
	INNER JOIN cust_SECC_payment_gateway CSPG WITH(NOLOCK) ON A.[Gateway Transaction ID] = CSPG.[Gateway Transaction ID]
	WHERE A.[Gateway Tender Type ID] <> A.[Arena Tender Type ID] OR A.[Gateway Amount] <> A.[Arena Amount]
END

/* to fix above
DECLARE @NewAmount FLOAT;
SET @NewAmount = [float value from Gateway Amount column];
DECLARE @NewTenderTypeID INT;
SET @NewTenderTypeID = [integer value from Gateway Tender Type ID column];

UPDATE PT
SET payment_method_luid = @NewTenderTypeID, date_modified = GETDATE(), modified_by = 'Accounting', transaction_amount=@NewAmount
FROM pmnt_transaction PT

UPDATE CC
SET currency_type_luid = @NewTenderTypeID, date_modified = GETDATE(), modified_by = 'Accounting',currency_amount=@NewAmount
FROM ctrb_contribution CC
*/
GO


